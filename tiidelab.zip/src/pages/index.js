export * from "./Home";
export * from "./About";
export * from "./Contact";
export * from "./Gallery";
export * from "./Apply";
